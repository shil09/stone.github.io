# About

This is my blog based on jekyll. And I change the style and interactive. If you want to use this model of the blog. **Please give a star at this repository**. Then you can clone it as your blog model.

You can visit [here](http://gaohaoyang.github.io) to see this blog.

---

这是我的博客，基于 jekyll。我改了所有默认的样式和交互。如果你想使用这个博客模板。**请先在这个仓库上点个star吧**，这也是对我的肯定和鼓励，谢谢了。然后你可以克隆这个仓库用作你自己的博客。

博客访问地址：[点击这里](http://gaohaoyang.github.io)

**使用时请注明模板来源:  Jekyll theme by [Gaohaoyang](https://github.com/Gaohaoyang/gaohaoyang.github.io)**

<!--

## 被引用信息

使用了我的模板并写明来源的人：   

* [dreamholy](http://dreamholy.github.io/)

没有注明来源的人：

* [yangshuailing](http://yangshuailing.github.io/com/)
* [huapu728](http://huapu728.github.io/)
* [greatbuger](http://greatbuger.github.io/) 


-->


